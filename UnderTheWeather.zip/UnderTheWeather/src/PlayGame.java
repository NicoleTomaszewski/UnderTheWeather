import javax.swing.*;
import javax.swing.text.html.HTML;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.ArrayList;

public class PlayGame {

    public static ImageIcon test;
    public static ImageIcon w;
    public static ImageIcon b;
    public static ImageIcon b_bottle;
    public static ImageIcon b_bottle_wetCloth;
    public static ImageIcon b_cloth;
    public static ImageIcon b_cloth_bottle;
    public static ImageIcon k;
    public static ImageIcon k_bottle;
    public static ImageIcon p;
    public static ImageIcon p_dog;
    public static ImageIcon p_dog_bone;
    public static ImageIcon n;
    public static ImageIcon n_sink;
    public static ImageIcon m;
    public static ImageIcon m_dog;
    public static ImageIcon g;
    public static ImageIcon g_bone;
    public static ImageIcon g_bone_coat;
    public static ImageIcon g_bone_coat_flower;
    public static ImageIcon g_bone_flower;
    public static ImageIcon g_flower;

    public static final String TITLE = "Under the Weather";
    public static final String HTML_START = "<html><div style='text-align: center;'>";
    public static final String HTML_END = "</div></html>";
    public static JFrame frame;
    public static JPanel Npanel;
    public static JPanel Cpanel;
    public static JPanel Spanel;

    public static int alex;
    public static int joke;
    public static boolean hadOilConvo;
    public static boolean isDistracted;
    public static boolean hadBoneConvo;
    public static boolean complete;
    public static boolean stopAlex;

    public static boolean haveBottle;
    public static boolean haveCloth;
    public static boolean haveSink;
    public static boolean haveWetCloth;
    public static boolean havePie;
    public static boolean haveLeash;
    public static boolean haveRug;
    public static boolean haveFlower;
    public static boolean haveCoat;
    public static boolean haveOil;
    public static boolean haveWD;
    public static boolean haveBone;
    public static boolean haveMeat;
    public static boolean haveDog;

    public static boolean tookBottle;
    public static boolean tookCloth;
    public static boolean tookWetCloth;
    public static boolean tookPie;
    public static boolean tookLeash;
    public static boolean tookRug;
    public static boolean tookFlower;
    public static boolean tookCoat;
    public static boolean tookOil;
    public static boolean tookWD;
    public static boolean tookBone;
    public static boolean tookMeat;
    public static boolean tookDog;

    public static ArrayList<String> inventory;

    /*
    -Runs the game
     */
    public static void main(String[] args) {

        getImages();
        startgame();

        bedroom();

    }

    public static void win() {

        clearPanels();

        JLabel label = new JLabel(HTML_START + "Congrats, your roommate, Alex, is on the mend!<br><br>" +
                "This is the end of the game, but if you haven't finished exploring, you can continue to play.<br>" +
                "Thanks for playing Under the Weather!<br><br>Credits:<br>Programmer: Nicole Tomaszewski<br>" +
                "Designer: Nicole Tomaszewski<br>Artist: Nicole Tomaszewski", SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Win");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton playB = new JButton("Keep Playing");
        Spanel.add(playB, BorderLayout.WEST);
        playB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bedroom();
            }
        });

        JButton endB = new JButton("End Game");
        Spanel.add(endB, BorderLayout.EAST);
        endB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });

        frame.setVisible(true);

    }

    /*
    -Gets all images
     */
    public static void getImages() {

        test = new ImageIcon("src/Images/test.png");
        w = new ImageIcon("src/Images/W.png");
        b = new ImageIcon("src/Images/B.png");
        b_bottle = new ImageIcon("src/Images/B-bottle.png");
        b_bottle_wetCloth = new ImageIcon("src/Images/B-bottle-wetCloth.png");
        b_cloth = new ImageIcon("src/Images/B-cloth.png");
        b_cloth_bottle = new ImageIcon("src/Images/B-cloth-bottle.png");
        k = new ImageIcon("src/Images/K.png");
        k_bottle = new ImageIcon("src/Images/K-bottle.png");
        p = new ImageIcon("src/Images/P.png");
        p_dog = new ImageIcon("src/Images/P-dog.png");
        p_dog_bone = new ImageIcon("src/Images/P-dog-bone.png");
        n = new ImageIcon("src/Images/N.png");
        n_sink = new ImageIcon("src/Images/N-sink.png");
        m = new ImageIcon("src/Images/M.png");
        m_dog = new ImageIcon("src/Images/M-dog.png");
        g = new ImageIcon("src/Images/G.png");
        g_bone = new ImageIcon("src/Images/G-bone.png");
        g_bone_coat = new ImageIcon("src/Images/G-bone-coat.png");
        g_bone_coat_flower = new ImageIcon("src/Images/G-bone-coat-flower.png");
        g_bone_flower = new ImageIcon("src/Images/G-bone-flower.png");
        g_flower = new ImageIcon("src/Images/G-flower.png");

    }

    /*
    -Initializes inventory and other variables
    -Initializes JFrame
    -Shows title and basic info
     */
    public static void startgame() {

        inventory = new ArrayList<>();

        alex = 0;
        joke = 0;
        hadOilConvo = false;
        hadBoneConvo = false;
        isDistracted = false;
        complete = false;
        stopAlex = false;

        haveBottle = false;
        haveCloth = false;
        haveSink = false;
        haveWetCloth = false;
        havePie = false;
        haveLeash = false;
        haveRug = false;
        haveFlower = false;
        haveCoat = false;
        haveOil = false;
        haveWD = false;
        haveBone = false;
        haveMeat = false;
        haveDog = false;

        tookBottle = false;
        tookCloth = false;
        tookWetCloth = false;
        tookPie = false;
        tookLeash = false;
        tookRug = false;
        tookFlower = false;
        tookCoat = false;
        tookOil = false;
        tookWD = false;
        tookBone = false;
        tookMeat = false;
        tookMeat = false;

        frame = new JFrame(TITLE);
        frame.setSize(1100,600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        Npanel = new JPanel();
        Cpanel = new JPanel();
        Spanel = new JPanel();
        frame.add(Npanel, BorderLayout.NORTH);
        frame.add(Cpanel, BorderLayout.CENTER);
        frame.add(Spanel, BorderLayout.SOUTH);

        UIManager.put("OptionPane.okButtonText", "Next");
        JOptionPane.showMessageDialog(null, "Welcome to Under the Weather!", TITLE, JOptionPane.PLAIN_MESSAGE);

        UIManager.put("OptionPane.okButtonText", "Start Game");
        JOptionPane.showMessageDialog(null, "You have come home to find that your roommate, Alex, is sick." +
                "\nExplore the map and talk to characters to help them feel better!\nThanks for playing!", TITLE, JOptionPane.PLAIN_MESSAGE);

        UIManager.put("OptionPane.okButtonText", "OK");

    }

    /*
    -location: function that chooseImage was called from
    -returns a JLabel to be used when making a JPanel
    -checks booleans to determine what items should be present in the image
     */
    public static JLabel chooseImage(String location) {

        JLabel output = null;

        switch (location) {
            case "Kitchen":
                if (tookBottle) {
                    output = new JLabel(k);
                } else {
                    output = new JLabel(k_bottle);
                }
                break;
            case "Bedroom":
            case "Alex":
                boolean bottle = tookBottle && !haveBottle;
                boolean cloth = !tookCloth;
                boolean wetCloth = tookWetCloth && !haveWetCloth;

                if (wetCloth) {
                    output = new JLabel(b_bottle_wetCloth);
                } else if (bottle && cloth) {
                    output = new JLabel(b_cloth_bottle);
                } else if (bottle) {
                    output = new JLabel(b_bottle);
                } else if (cloth) {
                    output = new JLabel(b_cloth);
                } else {
                    output = new JLabel(b);
                }

                break;
            case "Neighborhood":
            case "Laura":
                if (haveSink) {
                    output = new JLabel(n_sink);
                }
                else {
                    output = new JLabel(n);
                }
                break;
            case "Market":
            case "Tim":
            case "Timshop":
            case "Hambone":
                if (tookDog && !haveDog) {
                    output = new JLabel(m_dog);
                } else {
                    output = new JLabel(m);
                }
                break;
            case "Park":
            case "Dog":
            case "Shed":
                if (!tookDog && !tookBone) {
                    output = new JLabel(p_dog_bone);
                } else if (!tookDog && tookBone) {
                    output = new JLabel(p_dog);
                } else {
                    output = new JLabel(p);
                }
                break;
            case "Graveyard":
            case "Scully":
                boolean flower = tookFlower && !haveFlower;
                boolean bone = tookBone && !haveBone;
                boolean coat = tookCoat && !haveCoat;

                if (flower) {
                    if (coat) {
                        output = new JLabel(g_bone_coat_flower);
                    } else if (bone) {
                        output = new JLabel(g_bone_flower);
                    } else {
                        output = new JLabel(g_flower);
                    }
                } else {
                    if (coat) {
                        output = new JLabel(g_bone_coat);
                    } else if (bone) {
                        output = new JLabel(g_bone);
                    } else {
                        output = new JLabel(g);
                    }
                }

                break;
            case "Win":
                output = new JLabel(w);
                break;
            default:
                output = new JLabel(test);
                break;
        }

        return output;

    }

    /*
    -Calls removeAll(), revalidate(), and repaint() on all three panels
     */
    public static void clearPanels() {

        Npanel.removeAll();
        Cpanel.removeAll();
        Spanel.removeAll();

        Npanel.revalidate();
        Npanel.repaint();
        Cpanel.revalidate();
        Cpanel.repaint();
        Spanel.revalidate();
        Spanel.repaint();

    }

    /*
    -Adds the given item to the inventory
    -Changes the booleans for the item
    -Does not check if it is already in the inventory
     */
    public static void takeItem(String item) {

        boolean have = true;

        switch (item) {
            case "Water Bottle":
                have = haveBottle;
                haveBottle = true;
                tookBottle = true;
                break;
            case "Cloth":
                have = haveCloth;
                haveCloth = true;
                tookCloth = true;
                break;
            case "Wet Cloth":
                have = haveWetCloth;
                haveWetCloth = true;
                tookWetCloth = true;
                break;
            case "Slice of Pie":
                have = havePie;
                havePie = true;
                tookPie = true;
                break;
            case "Leash":
                have = haveLeash;
                haveLeash = true;
                tookLeash = true;
                break;
            case "Rug":
                have = haveRug;
                haveRug = true;
                tookRug = true;
                break;
            case "Flower":
                have = haveFlower;
                haveFlower = true;
                tookFlower = true;
                break;
            case "Coat":
                have = haveCoat;
                haveCoat = true;
                tookCoat = true;
                break;
            case "Oil Can":
                have = haveOil;
                haveOil = true;
                tookOil = true;
                break;
            case "WD-40":
                have = haveWD;
                haveWD = true;
                tookWD = true;
                break;
            case "Leg Bone":
                have = haveBone;
                haveBone = true;
                tookBone = true;
                break;
            case "Meat Scraps":
                have = haveMeat;
                haveMeat = true;
                tookMeat = true;
                break;
            case "Leashed Dog":
                have = haveDog;
                haveDog = true;
                tookDog = true;
                break;
        }

        if (!have) {
            inventory.add(item);
        }

    }

    /*
    -Removes the given item from the inventory
    -Changes the boolean for the item
     */
    public static void loseItem(String item) {

        switch (item) {
            case "Water Bottle":
                haveBottle = false;
                break;
            case "Cloth":
                haveCloth = false;
                break;
            case "Wet Cloth":
                haveWetCloth = false;
                break;
            case "Slice of Pie":
                havePie = false;
                break;
            case "Leash":
                haveLeash = false;
                break;
            case "Rug":
                haveRug = false;
                break;
            case "Flower":
                haveFlower = false;
                break;
            case "Coat":
                haveCoat = false;
                break;
            case "Oil Can":
                haveOil = false;
                break;
            case "WD-40":
                haveWD = false;
                break;
            case "Leg Bone":
                haveBone = false;
                break;
            case "Meat Scraps":
                haveMeat = false;
                break;
            case "Leashed Dog":
                haveDog = false;
                break;
        }

        int i = 0;
        while (!inventory.get(i).equals(item)) {
            i++;
        }
        inventory.remove(i);

    }

    /*
    -Shows the text provided
    -Assumes the text is already in HTML format
     */
    public static void showText(String text) {

        Npanel.removeAll();
        Npanel.revalidate();
        Npanel.repaint();

        JLabel label = new JLabel(text, SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);
        frame.setVisible(true);

    }

    public static void inventory(String location) {

        clearPanels();

        String list = "";
        for (int i = 0; i < inventory.size(); i++) {
            list = list + "<br><br>" + inventory.get(i);
        }

        if (inventory.size() == 0) {
            list = "<br><br>You don't have anything in your inventory!";
        }

        JLabel label = new JLabel(HTML_START + "Inventory" + list + HTML_END, SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JButton backB = new JButton("Back");
        Spanel.add(backB, BorderLayout.WEST);
        backB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                switch (location) {
                    case "Kitchen":
                        kitchen();
                        break;
                    case "Bedroom":
                        bedroom();
                        break;
                    case "Neighborhood":
                        neighborhood();
                        break;
                    case "Market":
                        market();
                        break;
                    case "Park":
                        park();
                        break;
                    case "Graveyard":
                        graveyard();
                        break;
                }
            }
        });

    }

    public static void bedroom() {

        clearPanels();

        JLabel label = new JLabel("Bedroom", SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Bedroom");
        Cpanel.add(image, BorderLayout.CENTER);

        if (!complete) {

            JButton inventoryB = new JButton("Inventory");
            Spanel.add(inventoryB, BorderLayout.WEST);
            inventoryB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    inventory("Bedroom");
                }
            });

            JButton alexB = new JButton("Talk to Alex");
            Spanel.add(alexB, BorderLayout.CENTER);
            alexB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    alex();
                }
            });

            if (!tookCloth) {
                JButton clothB = new JButton("Take Cloth");
                Spanel.add(clothB, BorderLayout.CENTER);
                clothB.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        takeItem("Cloth");
                        bedroom();
                        showText(HTML_START + "Bedroom<br><br>You took the cloth." + HTML_END);
                    }
                });
            }

            if (haveBottle) {
                JButton bottleB = new JButton("Give Water Bottle");
                Spanel.add(bottleB, BorderLayout.CENTER);
                bottleB.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        loseItem("Water Bottle");
                        bedroom();
                        showText(HTML_START + "Bedroom<br><br>You give Alex their water bottle. They look a little better!" +
                                "<br><br>Unfortunately, they're still running a fever. " +
                                "You think you should get them a wet cloth for their forehead." + HTML_END);
                        alex = 3;

                    }
                });
            }

        /*
        if (haveWetCloth) {
            JButton wetClothB = new JButton("Give Wet Cloth");
            Spanel.add(wetClothB, BorderLayout.CENTER);
            wetClothB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    loseItem("Wet Cloth");
                    alex = 11;
                    bedroom();
                    showText(HTML_START + "Bedroom<br><br>You give Alex the wet cloth. Feeling better, they start to take a nap." +
                            "<br><br>You hear their stomach growl in their sleep. " + HTML_END);
                }
            });
        }
         */
            if (haveWetCloth) {
                JButton wetClothB = new JButton("Give Wet Cloth");
                Spanel.add(wetClothB, BorderLayout.CENTER);
                wetClothB.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        loseItem("Wet Cloth");
                        alex = 11;
                        complete = true;
                        stopAlex = true;
                        bedroom();
                        showText(HTML_START + "Bedroom<br><br>You give Alex the wet cloth. " +
                                "Feeling much better, they settle down for a nap." + HTML_END);
                    }
                });
            }

            JButton kitchenB = new JButton("Go to Kitchen");
            Spanel.add(kitchenB, BorderLayout.EAST);
            kitchenB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    kitchen();
                }
            });

        } else {
            complete = false;

            JButton nextB = new JButton("Next");
            Spanel.add(nextB, BorderLayout.CENTER);
            nextB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    win();
                }
            });
        }

        frame.setVisible(true);

    }

    public static void kitchen() {

        clearPanels();

        JLabel label = new JLabel("Kitchen", SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Kitchen");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton inventoryB = new JButton("Inventory");
        Spanel.add(inventoryB, BorderLayout.WEST);
        inventoryB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                inventory("Kitchen");
            }
        });

        JButton sinkB = new JButton("Use Sink");
        Spanel.add(sinkB, BorderLayout.CENTER);
        sinkB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sink();
            }
        });

        if (!tookBottle) {
            JButton bottleB = new JButton("Take Water Bottle");
            Spanel.add(bottleB, BorderLayout.CENTER);
            bottleB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    takeItem("Water Bottle");
                    alex = 2;
                    kitchen();
                    showText(HTML_START + "Kitchen<br><br>You took the water bottle." + HTML_END);
                }
            });
        }

        JButton bedroomB = new JButton("Go to Bedroom");
        Spanel.add(bedroomB, BorderLayout.EAST);
        bedroomB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bedroom();
            }
        });

        JButton outsideB = new JButton("Go Outside");
        Spanel.add(outsideB, BorderLayout.EAST);
        outsideB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                neighborhood();
            }
        });

        frame.setVisible(true);

    }

    public static void neighborhood() {

        clearPanels();

        JLabel label = new JLabel("Neighborhood", SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Neighborhood");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton inventoryB = new JButton("Inventory");
        Spanel.add(inventoryB, BorderLayout.WEST);
        inventoryB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                inventory("Neighborhood");
            }
        });

        JButton lauraB = new JButton("Talk to Ms. Laura");
        Spanel.add(lauraB, BorderLayout.CENTER);
        lauraB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                laura();
            }
        });

        if (haveWD && !haveSink) {
            JButton wdB = new JButton("Use WD-40");
            Spanel.add(wdB, BorderLayout.CENTER);
            wdB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    haveSink = true;
                    if (tookBottle && !haveBottle) {
                        alex = 10;
                    }
                    neighborhood();
                    showText(HTML_START + "Neighborhood<br><br>You use the WD-40 and turn the water back on.<br><br>" +
                            "Ms. Laura looks relieved and gives you a smile." + HTML_END);
                }
            });
        }

        if (haveOil && !haveSink) {
            JButton oilB = new JButton("Use Oil Can");
            Spanel.add(oilB, BorderLayout.CENTER);
            oilB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    haveSink = true;
                    alex = 10;
                    neighborhood();
                    showText(HTML_START + "Neighborhood<br><br>You use the oil can and turn the water back on.<br><br>" +
                            "Ms. Laura looks relieved and gives you a smile." + HTML_END);
                }
            });
        }

        JButton parkB = new JButton("Go to Park");
        Spanel.add(parkB, BorderLayout.EAST);
        parkB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                park();
            }
        });

        JButton houseB = new JButton("Go to your House");
        Spanel.add(houseB, BorderLayout.EAST);
        houseB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                kitchen();
            }
        });

        JButton marketB = new JButton("Go to Market");
        Spanel.add(marketB, BorderLayout.EAST);
        marketB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                market();
            }
        });

        frame.setVisible(true);

    }

    public static void market() {

        clearPanels();

        JLabel label = new JLabel("Market", SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Market");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton inventoryB = new JButton("Inventory");
        Spanel.add(inventoryB, BorderLayout.WEST);
        inventoryB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                inventory("Market");
            }
        });

        JButton timB = new JButton("Talk to Tim the Tinman");
        Spanel.add(timB, BorderLayout.CENTER);
        timB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tim();
            }
        });

        JButton hamboneB = new JButton("Talk to Hambone");
        Spanel.add(hamboneB, BorderLayout.CENTER);
        hamboneB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                hambone();
            }
        });

        if (tookDog && !haveDog) {
            JButton wagyuB = new JButton("Pet Wagyu");
            Spanel.add(wagyuB, BorderLayout.CENTER);
            wagyuB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    showText(HTML_START + "Market<br><br>Wagyu waves his tail and licks your hand.");
                }
            });
        }

        JButton neighborhoodB = new JButton("Go to Neighborhood");
        Spanel.add(neighborhoodB, BorderLayout.EAST);
        neighborhoodB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                neighborhood();
            }
        });

        frame.setVisible(true);

    }

    public static void park() {

        clearPanels();

        JLabel label = new JLabel("Park", SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Park");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton inventoryB = new JButton("Inventory");
        Spanel.add(inventoryB, BorderLayout.WEST);
        inventoryB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                inventory("Park");
            }
        });

        if (!tookDog) {
            JButton dogB = new JButton("Interact with Dog");
            Spanel.add(dogB, BorderLayout.CENTER);
            dogB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    dog();
                }
            });
        }

        JButton shedB = new JButton("Look in Shed");
        Spanel.add(shedB, BorderLayout.CENTER);
        shedB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                shed();
            }
        });

        JButton graveyardB = new JButton("Go to Graveyard");
        Spanel.add(graveyardB, BorderLayout.EAST);
        graveyardB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                graveyard();
            }
        });

        JButton neighborhoodB = new JButton("Go to Neighborhood");
        Spanel.add(neighborhoodB, BorderLayout.EAST);
        neighborhoodB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                neighborhood();
            }
        });

        frame.setVisible(true);

    }

    public static void graveyard() {

        clearPanels();

        JLabel label = new JLabel("Graveyard", SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Graveyard");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton inventoryB = new JButton("Inventory");
        Spanel.add(inventoryB, BorderLayout.WEST);
        inventoryB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                inventory("Graveyard");
            }
        });

        JButton scullyB = new JButton("Talk to Scully");
        Spanel.add(scullyB, BorderLayout.CENTER);
        scullyB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                scully();
            }
        });

        if (haveFlower) {
            JButton flowerB = new JButton("Place Flower");
            Spanel.add(flowerB, BorderLayout.CENTER);
            flowerB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    loseItem("Flower");
                    graveyard();
                    showText(HTML_START + "Graveyard<br><br>You place the flower at the only grave without one." + HTML_END);
                }
            });
        }

        JButton parkB = new JButton("Go to Park");
        Spanel.add(parkB, BorderLayout.EAST);
        parkB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                park();
            }
        });

        frame.setVisible(true);

    }

    public static void sink() {

        if (haveSink && haveCloth && tookBottle && !haveBottle) {
            takeItem("Wet Cloth");
            loseItem("Cloth");
            showText(HTML_START + "Kitchen<br><br>You wet the cloth." + HTML_END);
        } else if (!haveSink) {
            showText(HTML_START + "Kitchen<br><br>That's weird. You turn the faucet, but nothing comes out." + HTML_END);
            if (alex == 3) {
                alex++;
            }
        } else {
            showText(HTML_START + "Kitchen<br><br>You turn on the faucet and then turn it off again." + HTML_END);
        }

    }

    public static void alex() {

        clearPanels();

        if (stopAlex) {
            alex = 11;
        }

        String dialogue = HTML_START + "Alex<br><br>";
        switch (alex) {
            case 0:
                dialogue = dialogue + "Hey, I'm not feeling too good. I think I've got a fever.<br><br>" +
                        "Could you get me my water bottle? I left it in the kitchen.";
                alex++;
                break;
            case 1:
                dialogue = dialogue + "My water bottle is in the kitchen.";
                break;
            case 2:
                dialogue = dialogue + "Thanks for getting my water bottle! Could you bring it over to me, please?";
                break;
            case 3:
                dialogue = dialogue + "Could you get me a wet cloth?";
                break;
            case 4:
                dialogue = dialogue + "The sink's not working? Maybe the water's off. " +
                        "The water shutoff valve is outside if you want to check.";
                alex++;
                break;
            case 5:
                dialogue = dialogue + "Did you check the water shutoff valve outside?";
                break;
            case 6:
                dialogue = dialogue + "I don't think we have anything here to help Ms. Laura. " +
                        "You might be able to find something in the market though.";
                break;
            case 7:
                dialogue = dialogue + "I'm not surprised Tim wouldn't give you his oil can, he doesn't trust anybody." +
                        "<br><br>Maybe he would give it to you if you replaced it with something.";
                break;
            case 8:
                dialogue = dialogue + "Use the oil can on the water shutoff valve outside!";
                break;
            case 9:
                dialogue = dialogue + "Use the WD-40 on the water shutoff valve outside!";
                break;
            case 10:
                if (haveWetCloth) {
                    dialogue = dialogue + "Thanks, you could hand me the wet cloth, please?";
                } else {
                    dialogue = dialogue + "Could you wet the cloth in the sink, please?";
                }
                break;
                /*
            case 11:
                dialogue = dialogue + "Zzzzzzzzzz<br>Grrrrrrr<br>Zzzzzzzzzz<br><br>" +
                        "You hear their stomach growl amidst their snores.";
                break;
                 */
            case 11:
                dialogue = dialogue + "Zzzzzzzzzz<br>Zzzzzzzzzz<br>Zzzzzzzzzz<br><br>";
                break;
        }
        dialogue = dialogue + HTML_END;

        JLabel label = new JLabel(dialogue, SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Alex");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton backB = new JButton("Back");
        Spanel.add(backB, BorderLayout.CENTER);
        backB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bedroom();
            }
        });

        frame.setVisible(true);

    }

    public static void laura() {

        clearPanels();

        JLabel label = new JLabel(HTML_START + "Ms. Laura<br><br>Hello, friend!" + HTML_END, SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Laura");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton backB = new JButton("Back");
        Spanel.add(backB, BorderLayout.WEST);
        backB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                neighborhood();
            }
        });

        if (!haveSink) {
            JButton waterB = new JButton("Did you shut off the water?");
            Spanel.add(waterB, BorderLayout.CENTER);
            waterB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    showText(HTML_START + "Ms. Laura<br><br>Yeah, I was doing some repairs on my shower.<br><br>" +
                            "But now I can't turn it back on again, it's stuck!" + HTML_END);
                    if ((alex < 6) && (tookBottle && !haveBottle)) {
                        alex = 6;
                        if (haveWD) {
                            alex = 9;
                        }
                    }
                }
            });
        }

        JButton pieB = new JButton("Could I have a slice of your pie?");
        Spanel.add(pieB, BorderLayout.CENTER);
        pieB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (!tookPie) {
                    showText(HTML_START + "Ms. Laura<br><br>Of course! Here you go." + HTML_END);
                    takeItem("Slice of Pie");
                } else {
                    showText(HTML_START + "Ms. Laura<br><br>You already had a slice!" + HTML_END);
                }
            }
        });

        frame.setVisible(true);

    }

    public static void tim() {

        clearPanels();

        JLabel label = new JLabel(HTML_START + "Tim the Tinman<br><br>Welcome to the Yard Sale." + HTML_END, SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Tim");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton backB = new JButton("Back");
        Spanel.add(backB, BorderLayout.WEST);
        backB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                market();
            }
        });

        JButton stuffB = new JButton("Where did you get all this stuff?");
        Spanel.add(stuffB, BorderLayout.CENTER);
        stuffB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showText(HTML_START + "Tim the Tinman<br><br>Can't say, I'm under oath." + HTML_END);
            }
        });

        JButton freeB = new JButton("Why is everything free?");
        Spanel.add(freeB, BorderLayout.CENTER);
        freeB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showText(HTML_START + "Tim the Tinman<br><br>I need to get rid of it. For reasons..." + HTML_END);
            }
        });

        JButton itemB = new JButton("Could I take this?");
        Spanel.add(itemB, BorderLayout.EAST);
        itemB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                timshop();
            }
        });

        if (alex >= 6) {
            if (!hadOilConvo || (!haveWD && !tookOil)) {
                JButton oilB = new JButton("Do you have an oil can?");
                Spanel.add(oilB, BorderLayout.EAST);
                oilB.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        alex = 7;
                        hadOilConvo = true;
                        tim();
                        showText(HTML_START + "Tim the Tinman<br><br>Yes! I am a tinman after all.<br><br>" +
                                "But why should I give it to you? You could forget to bring it back and then I'd be stuck forever!" +
                                "<br><br>Sorry, but I gotta stay alert, always gotta be on my toes." + HTML_END);
                    }
                });
            } else if (haveWD){
                JButton wdB = new JButton("Trade oil can for WD-40?");
                Spanel.add(wdB, BorderLayout.EAST);
                wdB.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        takeItem("Oil Can");
                        loseItem("WD-40");
                        if (!haveSink) {
                            alex = 8;
                        }
                        tim();
                        showText(HTML_START + "Tim the Tinman<br><br>Oooooh, yes please.<br><br>" +
                                "Wow, this is so much better than my oil can!" + HTML_END);
                    }
                });
            }
        }

        frame.setVisible(true);

    }

    public static void scully() {

        clearPanels();

        String dialog = "";
        if (!tookBone || !hadBoneConvo) {
            dialog = "Can I getch'yer help down here?";
        } else if (tookBone && haveBone) {
            dialog = "Ye found it!";
        } else {
            dialog = "Shiver me timbers!";
        }

        JLabel label = new JLabel(HTML_START + "Scully<br><br>" + dialog + HTML_END, SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Scully");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton backB = new JButton("Back");
        Spanel.add(backB, BorderLayout.WEST);
        backB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                graveyard();
            }
        });

        if (!tookBone || !hadBoneConvo) {
            JButton wrongB = new JButton("What's wrong?");
            Spanel.add(wrongB, BorderLayout.CENTER);
            wrongB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    hadBoneConvo = true;
                    scully();
                    showText(HTML_START + "Scully<br><br>A lil' doggie stole me leg! Me leg!<br><br>" +
                            "Now I can't get out'er this here hole." + HTML_END);
                }
            });
        }

        if (haveBone && hadBoneConvo) {
            JButton boneB = new JButton("I have your leg!");
            Spanel.add(boneB, BorderLayout.CENTER);
            boneB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    loseItem("Leg Bone");
                    scully();
                    showText(HTML_START + "Scully<br><br>Shiver me timbers, I can't thank ye enough!" + HTML_END);
                }
            });
        }

        if (tookCoat && !haveCoat) {
            JButton jokeB = new JButton("Tell me a joke?");
            Spanel.add(jokeB, BorderLayout.CENTER);
            jokeB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String output = joke();
                    joke++;
                    scully();
                    showText(HTML_START + "Scully<br><br>" + output + HTML_END);

                }
            });
        }

        if (tookBone && !haveBone && haveCoat) {
            JButton coatB = new JButton("Want a coat?");
            Spanel.add(coatB, BorderLayout.CENTER);
            coatB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    loseItem("Coat");
                    scully();
                    showText(HTML_START + "Scully<br><br>Thank you! I've been shivering in me boots!" + HTML_END);
                }
            });
        }

        JButton pirateB = new JButton("Are you a pirate?");
        Spanel.add(pirateB, BorderLayout.CENTER);
        pirateB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showText(HTML_START + "Scully<br><br>Do I be a pirate? O' course I be!<br><br>" +
                        "Yer lookin' at the fiercest pirate o' the high seas! No one was spared from me and me band o' bandits." + HTML_END);
            }
        });

        frame.setVisible(true);

    }

    public static void dog() {

        clearPanels();

        String dialogue = "";
        if (!tookBone) {
            dialogue = "The dog is gnawing on a bone.";
        } else {
            dialogue = "The dog is laying down and looks bored.";
        }

        JLabel label = new JLabel(HTML_START + "Dog<br><br>" + dialogue + HTML_END, SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Dog");
        Cpanel.add(image, BorderLayout.CENTER);

        String notDistracted = "<br><br>The dog is no longer distracted.";

        JButton backB = new JButton("Back");
        Spanel.add(backB, BorderLayout.WEST);
        backB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                isDistracted = false;
                park();
            }
        });

        JButton petB = new JButton("Pet");
        Spanel.add(petB, BorderLayout.CENTER);
        petB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (isDistracted && !tookBone) {
                    showText(HTML_START + "Dog<br><br>The dog waves his tail and licks your hand." + notDistracted + HTML_END);
                } else {
                    showText(HTML_START + "Dog<br><br>The dog waves his tail and licks your hand." + HTML_END);
                }
                isDistracted = false;
            }
        });

        if (havePie && hadBoneConvo && !tookDog) {
            JButton pieB = new JButton("Distract with Pie");
            Spanel.add(pieB, BorderLayout.CENTER);
            pieB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    isDistracted = true;
                    loseItem("Slice of Pie");
                    dog();
                    showText(HTML_START + "Dog<br><br>The dog chows down on the pie slice, momentarily distracted."
                            + HTML_END);
                }
            });
        }

        if (haveMeat && hadBoneConvo && !tookDog) {
            JButton meatB = new JButton("Distract with Meat Scraps");
            Spanel.add(meatB, BorderLayout.CENTER);
            meatB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    isDistracted = true;
                    loseItem("Meat Scraps");
                    dog();
                    showText(HTML_START + "Dog<br><br>The dog chows down on the meat scraps, momentarily distracted."
                            + HTML_END);
                }
            });
        }

        if (!tookBone && hadBoneConvo) {
            JButton boneB = new JButton("Take Bone");
            Spanel.add(boneB, BorderLayout.CENTER);
            boneB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (!isDistracted) {
                        showText(HTML_START + "Dog<br><br>You try to take the bone, but the dog evades you, running around the park happily."
                                + HTML_END);
                    } else {
                        takeItem("Leg Bone");
                        dog();
                        showText(HTML_START + "Dog<br><br>While the dog is busy eating, you quietly take the bone." + HTML_END);
                    }
                }
            });
        }

        if (haveLeash) {
            JButton leashB = new JButton("Leash Dog");
            Spanel.add(leashB, BorderLayout.CENTER);
            leashB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (tookBone) {
                        takeItem("Leashed Dog");
                        loseItem("Leash");
                        isDistracted = false;
                        park();
                        showText(HTML_START + "Park<br><br>The dog gladly follows you on the leash, tongue out." + HTML_END);
                    } else {
                        if (isDistracted) {
                            showText(HTML_START + "Dog<br><br>You try to leash the dog, but he thinks you're playing keep away with his bone!" +
                                    "<br><br>You cannot catch the dog." + notDistracted + HTML_END);
                        } else {
                            showText(HTML_START + "Dog<br><br>You try to leash the dog, but he thinks you're playing keep away with his bone!" +
                                    "<br><br>You cannot catch the dog." + HTML_END);
                        }
                        isDistracted = false;
                    }
                }
            });
        }

        frame.setVisible(true);

    }

    public static void hambone() {

        clearPanels();

        JLabel label = new JLabel(HTML_START + "Hambone<br><br>Hello there! Welcome to Hambone's Meats!"
                + HTML_END, SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Hambone");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton backB = new JButton("Back");
        Spanel.add(backB, BorderLayout.WEST);
        backB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                isDistracted = false;
                market();
            }
        });

        if ((hadBoneConvo || (alex >= 11)) && !tookMeat && !tookDog) {
            JButton meatB = new JButton("Can I have some meat?");
            Spanel.add(meatB, BorderLayout.CENTER);
            meatB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    takeItem("Meat Scraps");
                    hambone();
                    showText(HTML_START + "Hambone<br><br>Sorry, I've sold out.<br><br>All I have left are these scraps." +
                            " I've been trying to get rid of these for a while, so have as much as you want." + HTML_END);
                }
            });
        }

        if (tookMeat) {
            JButton scrapsB = new JButton("Can I have more scraps?");
            Spanel.add(scrapsB, BorderLayout.CENTER);
            scrapsB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    takeItem("Meat Scraps");
                    showText(HTML_START + "Hambone<br><br>Any time! I'm just happy I don't have to throw them away.");
                }
            });
        }

        if (tookMeat && tookDog && haveDog) {
            JButton dogB = new JButton("Do you want this dog?");
            Spanel.add(dogB, BorderLayout.CENTER);
            dogB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    loseItem("Leashed Dog");
                    hambone();
                    showText(HTML_START + "Hambone<br><br>Wow, what a cute little dog! Thank you very much!" +
                            "<br><br>I'll name him Wagyu and feed him all the meat scraps he wants." + HTML_END);
                }
            });
        }

        JButton nameB = new JButton("How'd you get your name?");
        Spanel.add(nameB, BorderLayout.CENTER);
        nameB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showText(HTML_START + "Hambone<br><br>Funny story! My mother had put a ham bone in her bean soup. Delicious!" +
                        "<br><br>After dinner she couldn't find it anywhere, until she found me chewing on it like a dog!" + HTML_END);
            }
        });

        frame.setVisible(true);

    }

    public static void timshop() {

        clearPanels();

        JLabel label = new JLabel(HTML_START + "Tim the Tinman<br><br>Sure, just take whatever." + HTML_END, SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Timshop");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton backB = new JButton("Back");
        Spanel.add(backB, BorderLayout.WEST);
        backB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tim();
            }
        });

        if (!tookLeash) {
            JButton leashB = new JButton("Leash");
            Spanel.add(leashB, BorderLayout.CENTER);
            leashB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    takeItem("Leash");
                    timshop();
                    showText(HTML_START + "Tim the Tinman<br><br>Anything else?" + HTML_END);
                }
            });
        }

        if (!tookRug) {
            JButton rugB = new JButton("Rug");
            Spanel.add(rugB, BorderLayout.CENTER);
            rugB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    takeItem("Rug");
                    timshop();
                    showText(HTML_START + "Tim the Tinman<br><br>Oh, there was a flower underneath. I wonder who put that there?" + HTML_END);
                }
            });
        }

        if (tookRug && !tookFlower) {
            JButton flowerB = new JButton("Flower");
            Spanel.add(flowerB, BorderLayout.CENTER);
            flowerB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    takeItem("Flower");
                    timshop();
                    showText(HTML_START + "Tim the Tinman<br><br>Anything else?" + HTML_END);
                }
            });
        }

        if (!tookCoat) {
            JButton coatB = new JButton("Coat");
            Spanel.add(coatB, BorderLayout.CENTER);
            coatB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    takeItem("Coat");
                    timshop();
                    showText(HTML_START + "Tim the Tinman<br><br>Finally someone's taking that ugly coat. " +
                            "It's been stinking up my yard sale for years." + HTML_END);
                }
            });
        }

        frame.setVisible(true);

    }

    public static void shed() {

        clearPanels();

        JLabel label = new JLabel("Shed", SwingConstants.CENTER);
        Npanel.add(label, BorderLayout.SOUTH);

        JLabel image = chooseImage("Shed");
        Cpanel.add(image, BorderLayout.CENTER);

        JButton backB = new JButton("Back");
        Spanel.add(backB, BorderLayout.WEST);
        backB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                park();
            }
        });

        if (!tookWD) {
            JButton wdB = new JButton("Take WD-40");
            Spanel.add(wdB, BorderLayout.CENTER);
            wdB.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    takeItem("WD-40");
                    if (!haveSink && (alex >= 6)) {
                        alex = 9;
                    }
                    shed();
                    showText(HTML_START + "Shed<br><br>You took the WD-40.");
                }
            });
        } else {
            showText(HTML_START + "Sheed<br><br>The shed is empty." + HTML_END);
        }

        frame.setVisible(true);

    }

    public static String joke() {

        if (joke > 5) {
            joke = 0;
        }

        String output = "";
        switch (joke) {
            case 0:
                output = "Why are pirates called pirates?<br><br>Because they arrrrr!";
                break;
            case 1:
                output = "How did the pirate find out he needed glasses?<br><br>" +
                        "They took an aye exam!";
                break;
            case 2:
                output = "Why couldn’t the pirates play cards?<br><br>" +
                        "Because the captain was standing on the deck!";
                break;
            case 3:
                output = "What happens if you take the p out of pirate?<br><br>" +
                        "They become irate!";
                break;
            case 4:
                output = "What do you call a pirate with three eyes?<br><br>Piiirate!";
                break;
            case 5:
                output = "Why does it take pirates so long to learn the alphabet?<br><br>" +
                        "Because they can spend years at C!";
                break;
        }
        output = output + "<br>Yar har har!";

        return output;

    }

}
